package com.example.btc;

import android.animation.ValueAnimator;
import android.app.Activity;
import android.icu.text.DecimalFormat;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.widget.TextView;
import androidx.wear.*;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.btc.databinding.ActivityMainBinding;

import org.json.JSONException;
import org.json.JSONObject;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

public class MainActivity extends Activity {

    private ActivityMainBinding binding;
    private com.android.volley.toolbox.Volley Volley;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());


        final TextView textView = (TextView) findViewById(R.id.textView);
        RequestQueue queue = Volley.newRequestQueue(this);

        DecimalFormat formatter = new DecimalFormat("#,###");
        String urlPrice = "https://api.gemini.com/v2/ticker/btcusd";

        JsonObjectRequest fetchPrice = new JsonObjectRequest
                (Request.Method.GET, urlPrice, null, new Response.Listener<JSONObject>() {

                    @Override
                    public void onResponse(JSONObject response) {
                        try {
                            double amount = Double.parseDouble(response.getString("close"));
                            textView.setText("$"+formatter.format(amount));
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                }, new Response.ErrorListener() {

                    @Override
                    public void onErrorResponse(VolleyError error) {
                        // TODO: Handle error

                    }
                });

        //Add the request.
        queue.add(fetchPrice);

        //Add request every 2 seconds.
        Runnable myRepeater = new Runnable() {
            public void run() {
                queue.add(fetchPrice);
            }
        };

        ScheduledExecutorService executor = Executors.newScheduledThreadPool(1);
        executor.scheduleAtFixedRate(myRepeater, 0, 2, TimeUnit.SECONDS);

    }


}